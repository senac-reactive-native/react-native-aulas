module.exports = {
  assets: ['./assets/fonts'],
  project: {
    ios: {
      automaticPodsInstallation: true
    }
  }
}