import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import EditarAtividade from './screens/EditarAtividades';
import MarkXXIII from './screens/MarkXXIII';
import { AtividadesProvider } from './contexts/AtividadesContext';

const Stack = createStackNavigator();

function App() {
    return (
      <AtividadesProvider>
        <NavigationContainer>
          <Stack.Navigator initialRouteName="MarkXXIII">
            <Stack.Screen name="MarkXXIII" component={MarkXXIII} options={{ headerShown: false }}/>
            <Stack.Screen name="EditarAtividade" component={EditarAtividade} />
          </Stack.Navigator>
        </NavigationContainer>
      </AtividadesProvider>
    );
  }

export default App;