import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    tituloContainer: {
        flex: 1,
        justifyContent: 'flex-end'
    },
    titulo: {
        fontFamily: 'Montserrat-Regular',
        fontSize: 50,
        marginLeft: 20,
        marginBottom: 30,
        color: '#FFF'
    },
    subtitulo: {
        fontFamily: 'Montserrat-Regular',
        marginLeft: 20,
        marginBottom: 30,
        fontSize: 20,
        color: '#FFF'
    },
    tasks: {
        flex: 7
    },
    background: {
        flex: 3
    },
    iconBar: {
        flexDirection: 'row',
        marginHorizontal: 20,
        justifyContent: 'flex-end'
    }
});

export default styles;