import React, {useState, useEffect} from "react";
import { View, TextInput, TouchableOpacity, Text, Alert } from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';
import styles from "../styles/ItensEstilos";

const EditarAtividade = ({route, navigation}) => {
    const { atividade } = route.params;
    const [ticketEditado, setTicketEditado] = useState(atividade);

    useEffect(() => {
        setTicketEditado(atividade);
    }, [atividade])

    const handleSave = async () => {
        try {
            // Recupera a lista atual de atividades do AsyncStorage
            const atividadesSalvas = await AsyncStorage.getItem('listaDeAtividades');
            let atividades = atividadesSalvas ? JSON.parse(atividadesSalvas) : [];
    
            // Encontra o índice do ticket atual na lista
            const index = atividades.findIndex((item) => item.ticketId === ticketEditado.ticketId);
    
            // Atualiza o ticket na lista ou adiciona se não existir
            if (index !== -1) {
                atividades[index] = ticketEditado;
            } else {
                atividades.push(ticketEditado);
            }
    
            // Salva a lista atualizada no AsyncStorage
            await AsyncStorage.setItem('listaDeAtividades', JSON.stringify(atividades));
    
            // Mostra um alerta de sucesso
            Alert.alert("Sucesso", "Atividade atualizada com sucesso!");
    
            // Retorna para a tela anterior
            navigation.goBack();
        } catch (error) {
            // Em caso de erro, mostra um alerta de erro
            console.error("Erro ao salvar atividade:", error);
            Alert.alert("Erro", "Não foi possível salvar a atividade.");
        }
    };

    return (
        <View style={styles.modalContainer}>
            <View style={styles.formContainer}>
                <Text style={styles.ticketId}>Ticket ID: {ticketEditado?.ticketId}</Text>
                <TextInput
                    style={styles.input}
                    value={ticketEditado?.resumo}
                    onChangeText={(text) => setTicketEditado({ ...ticketEditado, resumo: text })}
                    placeholder="Resumo"
                />
                <TouchableOpacity style={styles.closeButton} onPress={handleSave}>
                    <Text style={styles.closeButtonText}>Salvar</Text>
                </TouchableOpacity>
            </View>
        </View>
    )
}

export default EditarAtividade;